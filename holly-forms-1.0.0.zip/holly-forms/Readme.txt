=== Holly Forms ===
Contributors: ATTARI
Donate link: ""
Requires at least: 4.0
Tested up to: 6.6
Stable tag: 1.0.0
Requires PHP: 7.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html


== Description ==

this my first plugin i have published so this plugin will give you built forms you just need to take the shortcode and add it on you page easily


what makes my plugin different and special , my plugin is very safe and can't be hacked so if you setup my plugin your website will stay safe
and every time i will add forms for example contact form - login form - register forms and will be easy to use with the time i will add professional forms
coded with reactjs with animation and responsive with all devices that make your website has attractive forms it will look so professional


== How to Use? ==


1) you will create new page that called "registration" so the link of this page automatically will be site.com/registration
2) you will click on [+] search about shortcode
3) paste the shorcode in the version 1.0.0 we have only [custom_registration] shortcode form og registration when you will paste it will be automatically displayd on site.com/registration




Notice : you need to create pages called : registration __ thank-you __ conditions


Have good day