<?php
/*
 * Plugin Name: Holly forms
 * Description: This plugin [holly forms] will give you a built forms shortcodes easily to use you can take the short code and add it on your page and we guarante high secuirty that means our is plugin very safe 100%.
 * Version: 1.0.0
 * Author: ATTARI
 * License: GPLv2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html 
 */



//register_activation_hook(__FILE__,'first_func');



//add_action( 'init' , 'first_func');


// Register shortcode to display the registration form
include_once plugin_dir_path( __FILE__ ) . '/includes/DB.php';
include_once plugin_dir_path( __FILE__ ) . '/includes/register-form.php';
include_once plugin_dir_path( __FILE__ ) . '/includes/functions.php';



//executing database after activation plugin automatically

register_activation_hook( __FILE__ ,"wp_uf");



?>