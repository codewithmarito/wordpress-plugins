<?php



function wp_uf(){
  global $wpdb;
  $table_name = $wpdb->prefix.'users_information';
  $create_columns = "CREATE TABLE $table_name(
  id int(10) NOT NULL AUTO_INCREMENT,
  fullname VARCHAR (100) DEFAULT '',
  username VARCHAR (100) DEFAULT '',
  password VARCHAR (100) DEFAULT '',
  email VARCHAR (100) DEFAULT '',
  phone VARCHAR(100) DEFAULT '',
  PRIMARY KEY (id)
  );";
  require_once(ABSPATH.'/wp-admin/includes/upgrade.php');
  dbDelta($create_columns);
}




function wp_insert_uf($fullname,$username,$password,$email,$phone){
  global $wpdb;
  $table_name = $wpdb->prefix.'users_information';
  $wpdb->insert($table_name,
    array(
      'username'=> $username,
      'password'=>$password,
      'phone'=>$phone,
      'fullname'=>$fullname,
      'email'=>$email
    ),
    array(
      '%s',
      '%s',
      '%s',
      '%s',
      '%s'
    )
    );
}















?>