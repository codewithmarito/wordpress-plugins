<?php




//550px for forms leave it automatically


function register_form(){

  
  ob_start();
  ?>
  <div class="container" id="firstregister">
  <center>
    <img id="register" src="<?php echo(home_url('/wp-content/plugins/holly-forms/images/register.png')); ?>">
  </center>
  <form id="firstform" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" method="POST">
    <div class="mb-3">
      <input type="hidden" name="action" value="register_user">
      <label for="fullname" class="form-label">Full name</label>
      <input type="text" class="form-control" id="fullname" name="fullname" placeholder="Enter Full name" >
    </div>
    <div class="mb-3">
      <label for="username" class="form-label">Username</label>
      <input type="text" class="form-control" id="username" name="username" placeholder="Enter username" >
    </div>
    <div class="mb-3">
      <label for="exampleInputEmail1" class="form-label">Email address</label>
      <input type="email" placeholder="Enter email"  class="form-control" id="exampleInputEmail1" name="email" aria-describedby="emailHelp">
      <div id="emailHelp" class="form-text">We'll never share your email with anyone else.</div>
    </div>
    <div class="mb-3">
      <label for="exampleInputPassword1" class="form-label">Password</label>
      <input type="password" placeholder="Enter email" name="password" class="form-control" id="exampleInputPassword1">
    </div>
    <div class="form-group">
      <label for="phoneNumber">Phone Number</label>
      <input type="tel" name="phone" class="form-control" id="phoneNumber" placeholder="+1 xxx xxxx xx"
        title="Phone number format: 123-456-7890">
      </div>
      <br>
      <div class="mb-3 form-check">
        <input type="checkbox" class="form-check-input" id="exampleCheck1" name="terms" required>
        <label class="form-check-label" for="exampleCheck1">I agree to the <a href="<?php echo(home_url('/conditions'));?>" target="_blank">Terms and Conditions</a></label>
      </div> 
      <br>
      <br>
    <button type="submit" class="btn btn-primary">Submit</button>
      <br>
      <br>
  </form>
  </div>

  <?php
    return ob_get_clean();
    

}
add_shortcode('custom_registration', 'register_form');

function redirect_mama_if_logged_in() {
  // Check if the user is logged in and is visiting the 'mama' page
  if (is_page('registration') && is_user_logged_in() && !is_admin()) {
      // Redirect logged-in users to the homepage (or any URL you choose)
      wp_redirect(home_url());
      exit;
      
  }
}
add_action('template_redirect', 'redirect_mama_if_logged_in');








?>