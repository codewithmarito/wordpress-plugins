<?php



//adding bootstrap framework to the frontend 

function mytheme_enqueue_bootstrap() {
  // Enqueue Bootstrap CSS
  wp_enqueue_style('bootstrap-css', 'https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css' ,null);
  
  // Enqueue your custom CSS correctly
  wp_enqueue_style('holly-css', plugin_dir_url(dirname(__FILE__)). '/css/holly.css');

  // Enqueue Bootstrap JavaScript and dependencies
  wp_enqueue_script('bootstrap-js', 'https://stackpath.bootstrapcdn.com/bootstrap/5.3.0/js/bootstrap.bundle.min.js', array('jquery'), null, true);
}
add_action('wp_enqueue_scripts', 'mytheme_enqueue_bootstrap');
add_action( 'admin_enqueue_scripts', 'mytheme_enqueue_bootstrap' );


// this function for inserting data base of registration 
//first insert username and password and email to wp-users with subscriber role and then insert data wp_new_users


//create table wp_users_information




function get_info(){
  global $wpdb;
  //echo('starting<br><br>'); // This should print in the network tab if triggered correctly.
  $fullname = isset($_POST['fullname']) ? sanitize_text_field($_POST['fullname']) : '';
  $username = isset($_POST['username']) ? sanitize_text_field($_POST['username']) : '';
  $password = isset($_POST['password']) ? $_POST['password'] : ''; // Consider hashing
  $email = isset($_POST['email']) ? sanitize_email($_POST['email']) : '';
  $phone = isset($_POST['phone']) ? sanitize_text_field($_POST['phone']) : '';
  $user_data = array(
    'ID' => '',
    'user_login'=> $username,
    'user_pass'=> $password,
    'display_name'=> $fullname,
    'first_name'=> '',
    'last_name'=> '',
    'role' => 'contributor',
    'user_email' => $email
  );
  
  
  //inserting users with mode contributor
  if (!empty($username) && !empty($password) && !empty($email)) {
    //echo('hello all going fine');
    wp_insert_user($user_data);
    //echo('the usr has been created check your databasee');
    //require_once(plugin_dir_path( __FILE__ ).'/DB.php');
    wp_insert_uf($fullname,$username,$password,$email,$phone);
    //wp_die(); // Use wp_die() to stop processing if it's working in admin_post.
    wp_redirect(home_url('/thank-you'));
    //wp_die();
    exit;
  }else{
    wp_redirect(home_url('/registration'));
    exit;;
  }
  //die();

  //i will create table for wp_users_information then i will add columns 


}

//if(wp_get_referer() === home_url("/registration")){
add_action('admin_post_nopriv_register_user', 'get_info');
add_action('admin_post_register_user', 'get_info');




function form_shortcode(){
  ?>
  <center>
    <img id="logo" src="<?php echo(home_url('/wp-content/plugins/holly-forms/images/logo.png')); ?>">
  </center>
  <div class="container text-center">
    <div class="row align-items-center">
      <div class="col" id='col'>
        <h6>Shortcode form</h6>
      </div>
      <div class="col" id='col'>
      <h6>Image of the form</h6>
      </div>
      <div class="col" id='col'>
      <h6>description</h6>
      </div>
    </div>

    <div class="row align-items-center">
      <div class="col" id='col1'>
        <br>
        [custom_registration]
        <br><br>
      </div>
      <div class="col" id='col1'>
      <br>
      <a href='<?php echo(home_url()."/wp-content/plugins/holly-forms/images/registration-form.png") ?>' >See the form example</a>
      <br><br>
      </div>
      <div class="col" id='col1'>
        Here's a simple form that make you able to enter data to your database easily and this form very responsive on all devices
      </div>
    </div>
  </div>

  <?php
}

function second_tool_menu(){
  add_menu_page(
    'Marito',            // Page title
    'holly forms',    // Menu title
    'manage_options',   // Capability
    'holly-forms',            // Menu slug
    'form_shortcode',         // Callback function
    '',                 // Icon URL (optional, empty string if not needed)
    10                   // Position
  );
}


add_action('admin_menu', 'second_tool_menu');



?>